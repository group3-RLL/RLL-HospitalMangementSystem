export class User {
    id: number;
    username: string;
    password: string;
    role: string;
    name: string;
    age: string;
    gender: string;
    blood: string;
    dept: string
    phone: string;
    email: string;
    status: string;
    address: string;
    room: string;
}