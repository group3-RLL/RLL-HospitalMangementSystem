export class Invoice {
    id: string='';
    releasedate: string='';
    admitdate: string='';
    patientname: string='';
    patientmobile:string='';
    patientaddress:string='';
    disease:string='';
    roomcharge: string='';
    doctorfee: string='';
    medicinecost:string='';
    othercharge:string='';

    
        
}
