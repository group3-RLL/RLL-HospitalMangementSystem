export class Appointment {

    id: string;
    pname: string;
    symptoms: string
}
